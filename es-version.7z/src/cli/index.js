#!/usr/bin/env node

import { Command } from 'commander';

import { runCheckAllPackageVersion } from '../cliCollection/check-all-package-version';
import { runCommitRefresh } from '../cliCollection/commit-refresh';
import { runCreateDevelopScriptFiles } from '../cliCollection/create-assist-scripts.cli';
import { runCreateLernaProject } from '../cliCollection/create-lerna-project';
import { runSleep } from '../cliCollection/sleep';
import { runUpdateAllPackageVersion } from '../cliCollection/update-all-package-version';
import { readJsonFileSync } from '../tools/meta';

const program = new Command();

// eslint-disable-next-line no-undef
process.title = 'easy-soft-develop';

const packageJson = readJsonFileSync('../package.json');

program.version(packageJson.version).usage('<command> [options]');

program
  .command('create-assist-scripts')
  .description('create assist script files for your project')
  .action(() => {
    runCreateDevelopScriptFiles();
  });

program
  .command('check-all-package-version')
  .description('check all package version for your project')
  .action(() => {
    runCheckAllPackageVersion();
  });

program
  .command('update-all-package-version')
  .description('update all package version for your project')
  .action(() => {
    runUpdateAllPackageVersion();
  });

program
  .command('sleep')
  .description('sleep A few seconds with you want')
  .option('--second <number>', '')
  .option('--showInfo <bool>', 'show wait second info')
  .action((a, o) => {
    runSleep(a, o);
  });

program
  .command('commit-refresh')
  .description('update a flag file when commit')
  .option(
    '--fileName <number>',
    'flag file name, default is "commit.flag.json"',
  )
  .option('--relativeFolder <bool>', 'the folder flag file in it')
  .action((a, o) => {
    runCommitRefresh(a, o);
  });

program
  .command('create-lerna-project')
  .description('create a lerna project')
  .option('--name <string>', 'project name')
  .action((a, o) => {
    runCreateLernaProject(a, o);
  });

// eslint-disable-next-line no-undef
program.parse(process.argv);
