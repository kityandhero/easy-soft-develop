import { promptInfo, promptSuccess } from './meta';
import { loopPackage } from './package.tools';
import { exec } from './shell';

function adjustChildrenPackageJson(command) {
  loopPackage(({ name }) => {
    exec(`cd ./packages/${name} && ${command}`);
  });
}

export function initGlobalDevelopmentDependencePackages(packageList) {
  const packages = [packageList].flat();

  const command = `pnpm install -save-dev ${packages.join(' ')}`;

  function adjustMainPackageJson() {
    exec(command);
  }

  promptInfo(`${packages.join(',')} will install`);

  adjustChildrenPackageJson(command);

  adjustMainPackageJson();

  promptSuccess('install success');
}
