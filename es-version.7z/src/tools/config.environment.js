/* eslint-disable promise/no-nesting */
/* eslint-disable promise/no-promise-in-callback */

import { createDevelopScriptFiles } from './develop.assist';
import {
  assignObject,
  promptSuccess,
  readJsonFileSync,
  resolvePath,
  writeFileSync,
  writeJsonFileSync,
} from './meta';
import { globalScript } from './package.script';
import { loopPackage } from './package.tools';
import { prettierAllPackageJson } from './prettier.package.json';

function createMainFile(fileWithContentCollection) {
  if (!Array.isArray(fileWithContentCollection)) {
    return;
  }

  for (const o of fileWithContentCollection) {
    const { name, content } = o;

    writeFileSync(name, content);
  }

  const log = `main files [${fileWithContentCollection
    .map((o) => {
      const { name } = o;
      return name;
    })
    .join(',')}] refresh success`;

  promptSuccess(log);
}

function createPackageFile(fileWithContentCollection) {
  loopPackage(({ absolutePath }) => {
    const itemPath = absolutePath;

    if (!Array.isArray(fileWithContentCollection)) {
      return;
    }

    for (const o of fileWithContentCollection) {
      const { name, content } = o;

      writeFileSync(`${itemPath}/${name}`, content);
    }
  });

  const log = `package files [${fileWithContentCollection
    .map((o) => {
      const { name } = o;
      return name;
    })
    .join(',')}] refresh success`;

  promptSuccess(log);
}

function adjustMainPackageJson({ scripts }) {
  const mainProjectPath = resolvePath(`./package.json`);

  const packageJson = readJsonFileSync(mainProjectPath);

  packageJson.scripts = assignObject(
    globalScript,
    packageJson.scripts || {},
    scripts,
  );

  writeJsonFileSync(mainProjectPath, packageJson);

  promptSuccess('adjust main package.json success');
}

function adjustChildrenPackageJson({ scripts }) {
  loopPackage(({ absolutePath }) => {
    const itemPath = absolutePath;

    const childPackageJsonPath = `${itemPath}/package.json`;

    const packageJson = readJsonFileSync(childPackageJsonPath);

    packageJson.scripts = assignObject(packageJson.scripts || {}, scripts);

    writeJsonFileSync(childPackageJsonPath, packageJson);

    promptSuccess('adjust child package.json success');
  });
}

export function configEnvironment({
  mainFileContentList = [],
  packageFileContentList = [],
  mainScripts = {},
  childScripts = {},
}) {
  createDevelopScriptFiles();

  createMainFile(mainFileContentList || []);

  createPackageFile(packageFileContentList || []);

  adjustMainPackageJson({ scripts: mainScripts || {} });

  adjustChildrenPackageJson({ scripts: childScripts || {} });

  prettierAllPackageJson();
}
