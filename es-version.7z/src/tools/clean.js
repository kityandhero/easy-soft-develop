import { promptInfo, promptSuccess } from './meta';
import { loopPackage } from './package.tools';
import { exec } from './shell';

export function clean(preCmd, ...targets) {
  try {
    const list = targets.push('node_modules');

    const command = list
      .map((o) => {
        if (o) {
          return `npx rimraf ./${o}`;
        }
        return '';
      })
      .join(' && ');

    function adjustMainPackageJson() {
      exec(command);
    }

    function adjustChildrenPackageJson() {
      loopPackage(({ name }) => {
        exec(`cd ./packages/${name} && ${command}`);
      });
    }

    promptInfo(`clean start`);

    if (preCmd) {
      exec(preCmd);
    }

    adjustChildrenPackageJson();

    adjustMainPackageJson();

    promptSuccess('clean success');
  } catch {}
}
