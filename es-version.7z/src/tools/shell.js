import { cd as _cd, exec as _exec } from 'shelljs';

export function exec(cmd) {
  _exec(cmd);
}

export function cd(path) {
  return _cd(path);
}
