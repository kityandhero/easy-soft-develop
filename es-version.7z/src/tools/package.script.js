/* eslint-disable promise/no-nesting */
/* eslint-disable promise/no-promise-in-callback */

export const globalScript = {
  'z:initial:environment': 'node ./develop/assists/config.environment.js',
};

export const packageScript = {};

export function getGlobalPackages() {
  let packages = [];

  packages = [
    ...packages,
    '@commitlint/cli',
    '@commitlint/config-conventional',
    '@commitlint/config-lerna-scopes',
    '@commitlint/cz-commitlint',
    '@pmmmwh/react-refresh-webpack-plugin',
    'commitizen',
    'conventional-changelog-conventionalcommits',
  ];

  packages = [
    ...packages,
    'eslint',
    'eslint-config-prettier',
    'eslint-formatter-pretty',
    'eslint-import-resolver-typescript',
    'eslint-plugin-eslint-comments',
    'eslint-plugin-import',
    'eslint-plugin-prettier',
    'eslint-plugin-promise',
    'eslint-plugin-simple-import-sort',
  ];

  packages = [
    ...packages,
    'prettier',
    'prettier-plugin-organize-imports',
    'prettier-plugin-packagejson',
  ];

  packages = [
    ...packages,
    'stylelint',
    'stylelint-config-prettier',
    'stylelint-config-standard',
  ];

  packages = [
    ...packages,
    'rimraf',
    'lint-staged',
    'husky',
    'shelljs',
    'terminal-kit',
  ];

  packages = [...packages, 'easy-soft-develop'];

  return packages;
}
