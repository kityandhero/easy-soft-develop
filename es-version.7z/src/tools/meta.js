import { readJsonSync, writeJsonSync } from 'fs-extra';
import {
  accessSync,
  F_OK,
  mkdirSync as _mkdirSync,
  writeFileSync as _writeFileSync,
} from 'node:fs';
import { resolve } from 'node:path';
import { terminal as term } from 'terminal-kit';

export function resolvePath(path) {
  return resolve(path);
}

export function isObject(value) {
  return value !== null && typeof value === 'object';
}

//检测文件或者文件夹存在 nodeJS
export function fileExistsSync(path) {
  try {
    accessSync(path, F_OK);
  } catch {
    return false;
  }
  return true;
}

export function writeFileSync(path, content) {
  _writeFileSync(path, content);
}

export function checkStringIsEmpty(v) {
  v = ((v || undefined) == undefined ? '' : toString(v))
    .trim()
    .replace(/\t/g, ' ')
    .replace(/\r/g, ' ')
    .replace(/\n/g, ' ')
    .replace(/\s*/g, '');

  while (v.includes('  ')) {
    v = v.replace(/  /g, ' ');
  }

  return !v;
}

export function promptEmptyLine() {
  // eslint-disable-next-line no-undef
  console.log('');
}

export function promptSuccess(message) {
  term.nextLine(1);

  term.green(`${message}\r`);
  promptEmptyLine();
}

export function promptInfo(message) {
  term.white(`${message}\r`);
  promptEmptyLine();
}

export function promptError(message) {
  term.red(`${message}\r`);
  promptEmptyLine();
}

export function assignObject(source, mergeData) {
  let result = source;

  if (!Array.isArray(mergeData)) {
    if (!isObject(mergeData)) {
      return result;
    }

    return Object.assign(source, mergeData);
  }

  for (const o of mergeData) {
    if (!isObject(o)) {
      continue;
    }

    result = Object.assign(result, o);
  }

  return result;
}

export function mkdirSync(path) {
  if (checkStringIsEmpty(path)) {
    promptError('path disallow empty');

    return;
  }

  _mkdirSync(path, { recursive: true });
}

export function mkdirRelativeSync(path) {
  const currentPath = resolve('./');

  if (checkStringIsEmpty(path)) {
    promptError('relative path disallow empty');

    return;
  }

  _mkdirSync(`${currentPath}/${path}`, { recursive: true });
}

export function writeJsonFileSync(path, json) {
  writeJsonSync(path, json);
}

export function writeJsonFileRelativeSync(relativePath, json) {
  const path = resolve(relativePath);

  writeJsonFileSync(path, json);
}

export function readJsonFileSync(path) {
  return readJsonSync(path);
}

export function readJsonFileRelativeSync(relativePath) {
  return readJsonFileSync(resolve(relativePath));
}
