import { promptEmptyLine, promptInfo } from './meta';
import { exec } from './shell';

export function prettierAllPackageJson() {
  promptEmptyLine();
  promptInfo('will format all package.json');
  promptEmptyLine();

  exec('npx prettier --write ./**/package.json');
}

export function prettierCurrentPackageJson() {
  promptEmptyLine();
  promptInfo('will format current package.json');
  promptEmptyLine();

  exec('npx prettier --write ./package.json');
}
