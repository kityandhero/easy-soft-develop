import { lstatSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';

import { fileExistsSync } from './meta';

/**
 * loop all package
 */
export function loopPackage(
  callback = ({ name, absolutePath, relativePath }) => {},
) {
  const packagesDirectory = './packages/';

  if (!fileExistsSync(resolve(packagesDirectory))) {
    return;
  }

  const packagesPath = resolve(packagesDirectory);

  const files = readdirSync(packagesDirectory);

  for (const file of files) {
    const itemPath = `${packagesPath}/${file}`;

    if (file && lstatSync(itemPath).isDirectory()) {
      callback({
        name: file,
        absolutePath: itemPath,
        relativePath: `./packages/${file}`,
      });
    }
  }
}
