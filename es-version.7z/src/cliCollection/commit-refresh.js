import { commitRefresh } from '../tools/commit.refresh';

export function runCommitRefresh(s, o) {
  const {
    _optionValues: {
      fileName = 'commit.flag.json',
      relativeFolder = 'develop/flags',
    },
  } = o;

  commitRefresh(fileName, relativeFolder);
}
