import { sleep } from '../tools/sleep';

export function runSleep(s, o) {
  const {
    _optionValues: { second, showInfo = 'false' },
  } = o;

  sleep(second, showInfo == 'true');
}
