import { updateAllPackageVersion } from '../tools/package.update';

export function runUpdateAllPackageVersion() {
  updateAllPackageVersion();
}
