import { checkAllPackageVersion } from '../tools/package.update';

export function runCheckAllPackageVersion() {
  checkAllPackageVersion();
}
