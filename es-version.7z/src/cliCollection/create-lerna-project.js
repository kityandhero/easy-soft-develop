import { createLernaProject } from '../project/init-project';

export function runCreateLernaProject(s, o) {
  const {
    _optionValues: { name },
  } = o;

  createLernaProject(name);
}
