import { createDevelopScriptFiles } from '../tools/develop.assist';

export function runCreateDevelopScriptFiles() {
  createDevelopScriptFiles();
}
