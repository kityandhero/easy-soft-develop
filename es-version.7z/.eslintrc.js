/* eslint-disable no-undef */

module.exports = {
  plugins: ['unicorn', 'simple-import-sort', 'import', 'prettier'],
  extends: [
    'prettier',
    'plugin:unicorn/recommended',
    'plugin:promise/recommended',
  ],
  env: { es6: true },
  rules: {
    camelias: 0,
    'compat/compat': 0,
    'generator-star-spacing': 0,
    'linebreak-style': 0,
    'no-bitwise': 0,
    'no-use-before-define': 1,
    'no-nested-ternary': 0,
    'no-spaced-func': 2,
    'no-this-before-super': 0,
    'no-var': 2,
    'no-undef': 'error',
    'operator-linebreak': 0,
    'object-curly-newline': 0,
    'sort-imports': 0,
    '@typescript-eslint/no-this-alias': ['off'],
    '@typescript-eslint/no-unused-vars': 0,
    '@typescript-eslint/no-invalid-this': 0,
    'import/named': 'error',
    'import/export': 'error',
    'import/first': 'error',
    'import/newline-after-import': 'error',
    'import/no-duplicates': 'error',
    'import/no-absolute-path': 'error',
    // 开启将会极大增加检测执行时间
    'import/no-cycle': 0,
    'import/no-deprecated': 'error',
    'import/no-useless-path-segments': 'error',
    'import/no-unresolved': 'error',
    'import/no-unused-modules': 'error',
    'import/order': 0,
    'simple-import-sort/imports': [
      'error',
      {
        groups: [
          ['^(?!antd-management-fast-)(?!easy-soft-)[a-zA-Z0-9]', '^@(?!/)'],
          ['^(?!@/)(?!easy-soft-)(?!.)'],
          ['^easy-soft-'],
          ['^(?!@/)(?!antd-management-fast-)(?!.)'],
          ['^antd-management-fast-'],
          ['^((@/).*|$)'],
          ['^\\u0000'],
          ['^\\.\\.(?!/?$)', '^\\.\\./?$'],
          ['^\\./(?=.*/)(?!/?$)', '^\\.(?!/?$)', '^\\./?$'],
          ['^.+\\.s?less$', '^.+\\.s?scss$', '^.+\\.s?css$'],
        ],
      },
    ],
    'simple-import-sort/exports': 'error',
  },
  settings: {
    'import/parsers': {
      '@typescript-eslint/parser': ['.ts', '.tsx'],
    },
    'import/resolver': {
      node: {
        extensions: ['.js', '.jsx', '.ts', '.tsx'],
        moduleDirectory: ['src', 'node_modules'],
      },
      typescript: {
        // always try to resolve types under `<root>@types` directory even it doesn't contain any source code, like `@types/unIst`
        alwaysTryTypes: true,

        // use an array of glob patterns
        directory: ['./tsconfig.json', './packages/*/tsconfig.json'],
      },
    },
  },
};
