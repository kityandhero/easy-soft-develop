import { buildConfig } from './config/rollup-config';

const config = buildConfig({ terser: false });

// eslint-disable-next-line no-undef
console.log({ message: 'rollup.config.skip-compression.js' });

export default config;
