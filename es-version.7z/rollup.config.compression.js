import { buildConfig } from './config/rollup-config';

const config = buildConfig({ terser: true });

// eslint-disable-next-line no-undef
console.log({ message: 'rollup.config.compression.js' });

export default config;
