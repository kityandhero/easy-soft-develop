const { createPackageUpdateAllVersionScriptFile } = require('../src');

createPackageUpdateAllVersionScriptFile();
