const { createCommitRefreshScriptFile } = require('../src');

createCommitRefreshScriptFile();
