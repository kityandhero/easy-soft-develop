const { commitRefresh } = require('../src');

commitRefresh();
