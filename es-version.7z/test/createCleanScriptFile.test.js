const { createCleanScriptFile } = require('../src');

createCleanScriptFile();
