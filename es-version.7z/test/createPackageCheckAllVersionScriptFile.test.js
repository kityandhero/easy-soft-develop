const { createPackageCheckAllVersionScriptFile } = require('../src');

createPackageCheckAllVersionScriptFile();
