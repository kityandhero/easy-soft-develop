const { createSleepScriptFile } = require('../src');

createSleepScriptFile();
