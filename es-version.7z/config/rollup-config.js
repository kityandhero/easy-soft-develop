import { terser } from 'rollup-plugin-terser';
import typescript from 'rollup-plugin-typescript2';
import { DEFAULT_EXTENSIONS } from '@babel/core';
import babelConfig from '@rollup/plugin-babel';
import commonjs from '@rollup/plugin-commonjs';
import json from '@rollup/plugin-json';
import resolve from '@rollup/plugin-node-resolve';
import url from '@rollup/plugin-url';
import svgr from '@svgr/rollup';

const externalCollection = [
  'shelljs',
  'terminal-kit',
  'rimraf',
  'ping',
  'fs-extra',
  'download',
  'download-git-repo',
  'commander',
];

function buildConfigCore({
  inputFile,
  terser: whetherTerser = false,
  externalCollection: otherExternalCollection = [],
}) {
  const externals = [...externalCollection, ...(otherExternalCollection || [])];

  const config = {
    external: (d) => {
      return (
        /^react$/.test(d) ||
        /^@tarojs\/taro$/.test(d) ||
        /^@tarojs\/taro-h5$/.test(d) ||
        d.includes('@babel/runtime')
      );
    },
    input: inputFile,
    plugins: [
      json(),
      url(),
      svgr(),
      resolve({
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.json', '.svelte'],
        preferBuiltins: false,
      }),
      commonjs({
        include: ['node_modules/**', '../../node_modules/**'],
      }),
      typescript({
        // check: true,
        // verbosity: 3,
        tsconfig: 'tsconfig.json',
      }),
      babelConfig({
        extensions: [...DEFAULT_EXTENSIONS, 'ts', 'tsx'],
        plugins: [['@babel/plugin-transform-runtime']],
        babelHelpers: 'runtime',
      }),
    ],
    external: externals,
    output: {
      entryFileNames: '[name].js',
      dir: 'es',
      chunkFileNames: '[name].js',
      format: 'cjs',
      sourcemap: true,
    },
  };

  if (whetherTerser) {
    config.plugins.push(terser());
  }

  return config;
}

const inputFile = {
  index: 'src/index.js',
  'cli/index': 'src/cli/index.js',
};

export function buildConfig({ terser: whetherTerser = false }) {
  return buildConfigCore({ inputFile, terser: whetherTerser });
}
